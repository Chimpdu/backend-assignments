/* select buttons */
const submitButton = document.querySelector("#submit-data");
const searchButton = document.querySelector("#search");
/* 
* @description: POST user-typed 
* data to http://localhost:3000/todo 
*/
submitButton.addEventListener("click", ()=>{
    const nameValue = document.querySelector("#input-name").value;
    const taskValue = document.querySelector("#input-task").value;
    const todoList= [];
    todoList.push(taskValue)
    const jsonContent = {
        "name": nameValue,
        "todos": todoList
    }
    const container = document.querySelector(".status-div");
    fetch("http://localhost:3000/todo", {
        "method": "post",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(jsonContent)
    }) 
    .then(response=>{
        const message = response.text();
        return message
        
    }). then(message =>{
        const p = document.createElement("p");
        p.innerText = message;
        container.appendChild(p);
    })
    .catch((error)=>{
        console.error('Error:', error);
    })

    /* 
    * @description: GET query after post to get response from server. 
    * url http://localhost:3000/todo
    */
    /* const url = "http://localhost:3000/todo";
    const container = document.querySelector(".status-div");
    fetch(url)
    .then(response=>{
        const message = response.text();
        return message
        
    }). then(message =>{
        const p = document.createElement("p");
        p.innerText = message;
        container.appendChild(p);
    }).catch((error)=>{
        console.error('Error:', error);
    })*/

}) 

/* 
* @description: GET query for user's todo list by name 
* url http://localhost:3000/user/:id 
*/
searchButton.addEventListener("click", ()=>{
    const name = document.querySelector("#search-name").value;
    const url = `http://localhost:3000/user/${name}`;
    const container = document.querySelector(".display");
    fetch(url).then(response => {
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.indexOf("application/json") !== -1) {
          return response.json().then(data => {
            // The response was a JSON object
            // Process your data as a JavaScript object
            const p = document.createElement("p");
            /* string manipulation to get desired effect. */
            let content = `name: ${data.name}; things to do: `;
            const toduLst = Object.values(data.todos);
            toduLst.forEach(element =>{
                content += `<span class="delete-task" data-task= "${element}" data-id= "${data.name}">`+element + '</span>' + ", "
            })
            content = content.slice(0, content.lastIndexOf(","));
            p.innerHTML = content;
            container.appendChild(p);

            /* create delete user button */
            const deleteUserButton = document.createElement("button");
            deleteUserButton.setAttribute("id", "delete-user");
            deleteUserButton.innerText = "Delete user"
            container.appendChild(deleteUserButton);
            deleteUserButton.addEventListener("click", ()=>{
                deleteUser(data.name);
            })
            /* handle .delete-task to delete todos */
            const deleteSpans = document.querySelectorAll(".delete-task");
            deleteSpans.forEach((span)=>{
                span.addEventListener("click", (event)=>{
                let dataTask =event.target.getAttribute('data-task');
                let dataId =event.target.getAttribute('data-id');
                fetch("http://localhost:3000/user", {
                    method: "put",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                         "dataTask": dataTask,
                         "dataId": dataId
                        })
                })
                .then((response)=>{
                    return response.text();
                })
                .then((text)=>{
                    const deleteTaskDiv= document.querySelector(".delete-task-div");
                    const p = document.createElement("p");
                    p.innerText = text;
                    deleteTaskDiv.appendChild(p);
                })
                .catch((error)=>{
                    console.error("Error:", error);
                })
    })
})
          });
        } else {
          return response.text().then(text => {
            // The response wasn't a JSON object
            // Process your text as a String
            const p = document.createElement("p");
            p.innerText = text;
            container.appendChild(p);
          });
        }
      })
      .catch((error)=>{
        console.error('Error:', error);
    });
    
    
})


/* 
* @description send DELETE to user/:id to delete user.
*/
function deleteUser(id){
    url = `http://localhost:3000/user/${id}`;
    fetch(url, {
        method: "delete"
    })
    .then((response)=>{
        return response.text()
    })
    .then((text)=>{
        const deleteContainer = document.querySelector(".delete-div");
        const p = document.createElement("p");
        p.innerText = text;
        deleteContainer.appendChild(p);

    })
    .catch((error)=>{
        console.error('Error:', error);
    })
}

var express = require('express');
var router = express.Router();

/* store user input and declare isDuplicate*/
lst = [];
let isDuplicate;

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});
/* GET  search data*/
router.get("/user/:id", function(req, res, next){
    const id = req.params.id;
    /* check if found and handle found scenario */
    let isFound = false;
    lst.forEach(element =>{
      if (element.name==id) {
        isFound = true;
        res.json(element)
      }
    });
    if (!isFound) {
      res.send("User not found"); 
    }
    
})
/* POST add data */
router.post("/todo", function(req, res, next){
  if (req.body) {
    /* check duplicate name and deal with duplication */
    isDuplicate = false;
    lst.forEach(element => {
      if (element.name == req.body.name) {
        isDuplicate =true;
        element.todos.push(req.body.todos[0])
        res.send("Todo added");
      }
    });
    if (!isDuplicate) {
      lst.push(req.body);
      res.send("User added")
    }
    console.log(lst);
  }
});
/* GET response after POSTing data */
/* 
router.get("/todo", function(req, res, next){
  if (isDuplicate) {
    res.send("Todo added");
  } else res.send("User added")
}) */
/* DELETE user based on id */
router.delete("/user/:id", function(req, res, next){
  let isDeleted = false;
  const id = req.params.id;
  for (let i = 0; i < lst.length; i++) {
    if (id == lst[i].name){
      lst.splice(i, 1);
      isDeleted = true;
    }

    
  }  
  if (isDeleted) res.send("User deleted");
  else res.send("User not found");
})
/* PUT request to delete only the todo */
router.put("/user", function(req, res, next){
  let isDeletedTask = false;
  lst.forEach(element=>{
    if(element.name == req.body.dataId){
      for (let i = 0; i < element.todos.length; i++) {
        if (element.todos[i]==req.body.dataTask){
          element.todos.splice(i, 1);
          isDeletedTask = true;
        }
      }
      
    }
  })
  if (isDeletedTask) {
    res.send("Task deleted");
  } else {
    res.send("User not found");
  }
})
module.exports = router;

let lst = [];
const express = require("express");
router = express.Router();
router.get("/hello", (req, res)=>{
    res.json(JSON.parse('{"msg": "Hello world"}'));
    res.end();
});
router.get("/echo/:id", (req, res)=>{
    const content = JSON.parse(`{"id": "${req.params.id}"}`);
    console.log(`id: ${req.params.id} received and json sent`);
    res.json(content);
});
router.post("/sum", (req, res)=>{
    const numbers = Object.values(req.body.numbers);
    let result = 0;
    numbers.forEach(element =>{
        result+=element;
    });
    const returned = JSON.parse(`{"sum":${result}}`);
    console.log(returned);
    res.json(
        returned
    );
    res.end()
    
});
router.post("/list", (req, res)=>{
    const received = req.body.text;
    lst.push(received);
    /* console.log(lst); */
   
    res.json(JSON.parse(`{"list":${JSON.stringify(lst)}}`))
    
})
module.exports = router;
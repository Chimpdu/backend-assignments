const submitButton = document.querySelector("#submit-data");

submitButton.addEventListener("click", async ()=>{
    const value = document.querySelector("#input-text").value;
    await fetch("http://localhost:3000/list", {
        "method": "post",
        "headers": {
            "Content-type": "application/json"
        },
        "body": `{"text": "${value}"}`
    })

})
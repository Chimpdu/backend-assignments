
/* for now, just randomly fetch something.. */
const foodName = "pizza";
fetchRecipe(foodName);
/* Add new recipe */


let ingreList = [];
let instruList = [];

const ingreButton = document.querySelector("#add-ingredient");
const instruButton = document.querySelector("#add-instruction");
const submitButton = document.querySelector("#submit");

/* when the button is clicked, push data into the list */
ingreButton.addEventListener("click", ()=>{
    
    const ingre = document.querySelector("#ingredients-text").value;
    ingreList.push(ingre);
})
instruButton.addEventListener("click", ()=>{
    
    const instru = document.querySelector("#instructions-text").value;
    instruList.push(instru);
})

/* when submit button is clicked, post data and img files to the server */
submitButton.addEventListener("click", ()=>{
    const name = document.querySelector("#name-text").value;
    postData(name, ingreList, instruList);
    ingreList = [];
    instruList = [];
    /* post selected image files */
    const imgFiles = document.querySelector("#image-input").files;
    let formData = new FormData();
    for (let i = 0; i < imgFiles.length; i++) {
        formData.append("images", imgFiles[i]);
    }  
    
    console.log(formData.getAll("images"));
    postImg(formData);
})







/* functions */
async function fetchRecipe(foodName) {
    const fetched = await fetch(`http://localhost:3000/recipe/${foodName}`);
    const jsoned = await fetched.json();
    const name = jsoned.name;
    const instructions = Object.values(jsoned.instructions);
    const ingredients = Object.values(jsoned.ingredients);
    /* display the fetched data in html */
    const displayContainer = document.querySelector("#recipe-display");
    const header1 = document.createElement("h1");
    const header2 = document.createElement("h1");
    const header3 = document.createElement("h1"); 

    const list1 = document.createElement("ul");
    const list2 = document.createElement("ul");

    ingredients.forEach((element)=>{
        const li = document.createElement("li");
        li.innerText = element;
        list1.appendChild(li);
    })
    instructions.forEach((element)=>{
        const li = document.createElement("li");
        li.innerText = element;
        list2.appendChild(li);
    })
    
    header1.innerText = name;
    header2.innerText = "Ingredients";
    header3.innerText = "Instructions";

    displayContainer.appendChild(header1);
    displayContainer.appendChild(header2);
    displayContainer.appendChild(list1);
    displayContainer.appendChild(header3);
    displayContainer.appendChild(list2);
}

/* post new recipe to the server */
async function postData(name, ingreList, instruList){
    const url = "http://localhost:3000/recipe/";
    const contentJson = {
        "name": name,
        "ingredients": ingreList,
        "instructions": instruList
    };
    const contentString = JSON.stringify(contentJson); 
    const fetched = await fetch(url, {
        "method": "post",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": contentString
    }).catch((error)=>{
        console.error(error);
    })
}
/* post img files to the server */
async function postImg(formData){
    const url = "http://localhost:3000/images";
    
    const fetched = await fetch(url, {
        "method": "post",
        "body": formData
    }).catch((error)=>{
        console.error(error);
    })
}


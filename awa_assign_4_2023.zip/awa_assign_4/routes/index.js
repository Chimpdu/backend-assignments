recipeList = []
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});
/* GET retrieve recipe */
router.get("/recipe/:food", (req, res)=>{
  const foodName = req.params.food;
  const recipe = {
    "name": foodName,
    "instructions": ["preheat oven 225C", "slice mozzarellas", "put tomato sauce on pizza base", "put mozzarella slices on pizza", "bake for 15 min"],
    "ingredients": ["1 frozen pizza base", "1 tomato sauce", "2 mozzarellas"]
  };
  res.json(recipe);
})
/* POST, user send new recipe */
router.post("/recipe/", (req, res)=>{
  recipeList.push(req.body);
  console.log(req.body);
  res.json(req.body)
})
/* POST, user send images files in the format of FormData */
router.post("/images", (req, res)=>{
  res.send("Hi");
})
module.exports = router;

